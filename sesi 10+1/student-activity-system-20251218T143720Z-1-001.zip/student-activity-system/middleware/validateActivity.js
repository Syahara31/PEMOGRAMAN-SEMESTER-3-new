const validateActivity = (req, res, next) => {
    const { name, date, location } = req.body;
    if (!name || !date || !location) {
        return res.status(400).json({ message: "All fields required" });
    }
    if (isNaN(Date.parse(date))) {
        return res.status(400).json({ message: "Invalid date format" });
    }
    next();
};

module.exports = validateActivity;
