const fs = require("fs");
const path = require("path");

const logFilePath = path.join(__dirname, "../request.log");

const requestLogger = (req, res, next) => {
    const log = `${new Date().toISOString()} - ${req.method} ${req.url}\n`;
    console.log(log.trim());
    fs.appendFile(logFilePath, log, (err) => {
        if (err) console.error("Failed to write request log:", err);
    });
    next();
};

module.exports = requestLogger;
