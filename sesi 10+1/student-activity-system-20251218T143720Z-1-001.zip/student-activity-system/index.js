const express = require("express");
const bodyParser = require("body-parser");
const authRoutes = require("./routes/auth");
const activityRoutes = require("./routes/activities");
const requestLogger = require("./middleware/logger");

const app = express();
app.use(bodyParser.json());
app.use(requestLogger);

// Routes
app.use(authRoutes);
app.use("/activities", activityRoutes);

app.listen(3000, () => console.log("Server running at http://localhost:3000"));
