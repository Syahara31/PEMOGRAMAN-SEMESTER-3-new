const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const usersPath = path.join(__dirname, "../data/users.json");

// POST /register
router.post("/register", async (req, res) => {
    const { username, password, role } = req.body;
    if (!username || !password || !role) {
        return res.status(400).json({ message: "All fields required" });
    }

    let users = JSON.parse(fs.readFileSync(usersPath, "utf-8") || "[]");
    if (users.find(u => u.username === username)) {
        return res.status(400).json({ message: "Username already exists" });
    }

    const hashed = await bcrypt.hash(password, 10);
    users.push({ username, password: hashed, role });
    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
    res.json({ message: "User registered successfully" });
});

// POST /login
router.post("/login", async (req, res) => {
    const { username, password } = req.body;
    let users = JSON.parse(fs.readFileSync(usersPath, "utf-8") || "[]");
    const user = users.find(u => u.username === username);
    if (!user) return res.status(400).json({ message: "User not found" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ message: "Wrong password" });

    const token = jwt.sign({ username: user.username, role: user.role }, "secretkey123", { expiresIn: "1h" });
    res.json({ token });
});

module.exports = router;
