const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");
const auth = require("../middleware/auth");
const role = require("../middleware/role");
const validateActivity = require("../middleware/validateActivity");

const activitiesPath = path.join(__dirname, "../data/activities.json");

// GET /activities
router.get("/", auth, (req, res) => {
    let activities = JSON.parse(fs.readFileSync(activitiesPath, "utf-8") || "[]");
    res.json(activities);
});

// POST /activities (admin only)
router.post("/", auth, role(["admin"]), validateActivity, (req, res) => {
    let activities = JSON.parse(fs.readFileSync(activitiesPath, "utf-8") || "[]");
    const { name, date, location } = req.body;
    const newActivity = { id: Date.now(), name, date, location, participants: [] };
    activities.push(newActivity);
    fs.writeFileSync(activitiesPath, JSON.stringify(activities, null, 2));
    res.json({ message: "Activity created", activity: newActivity });
});

// PUT /activities/:id (admin only)
router.put("/:id", auth, role(["admin"]), validateActivity, (req, res) => {
    let activities = JSON.parse(fs.readFileSync(activitiesPath, "utf-8") || "[]");
    const { id } = req.params;
    const index = activities.findIndex(act => act.id == id);
    if (index === -1) return res.status(404).json({ message: "Activity not found" });
    activities[index] = { ...activities[index], ...req.body };
    fs.writeFileSync(activitiesPath, JSON.stringify(activities, null, 2));
    res.json({ message: "Activity updated", activity: activities[index] });
});

// POST /activities/:id/join (mahasiswa only)
router.post("/:id/join", auth, role(["mahasiswa"]), (req, res) => {
    let activities = JSON.parse(fs.readFileSync(activitiesPath, "utf-8") || "[]");
    const { id } = req.params;
    const activity = activities.find(act => act.id == id);
    if (!activity) return res.status(404).json({ message: "Activity not found" });
    if (activity.participants.includes(req.user.username)) {
        return res.status(400).json({ message: "Already joined" });
    }
    activity.participants.push(req.user.username);
    fs.writeFileSync(activitiesPath, JSON.stringify(activities, null, 2));
    res.json({ message: "Joined activity", activity });
});

module.exports = router;
